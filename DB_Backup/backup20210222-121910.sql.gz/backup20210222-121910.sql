--
-- backup20210222-121910.sql.gz


DROP TABLE IF EXISTS `brand`;
CREATE TABLE `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `brand_name` (`brand_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `brand` VALUES ('1','');
INSERT INTO `brand` VALUES ('2','Acer');
INSERT INTO `brand` VALUES ('3','Asus');
INSERT INTO `brand` VALUES ('9','Compaq');
INSERT INTO `brand` VALUES ('6','Dell');
INSERT INTO `brand` VALUES ('10','Fujitsu');
INSERT INTO `brand` VALUES ('5','HP');
INSERT INTO `brand` VALUES ('4','Lenovo');
INSERT INTO `brand` VALUES ('7','MSI');
INSERT INTO `brand` VALUES ('8','Toshiba');


DROP TABLE IF EXISTS `cardex`;
CREATE TABLE `cardex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `affichage` varchar(3) NOT NULL DEFAULT 'oui',
  `civilite` varchar(20) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(11) NOT NULL,
  `items_category` int(11) NOT NULL,
  `brand_category` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `historique` varchar(1000) NOT NULL,
  `join_date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `brand_category` (`brand_category`),
  KEY `items_category` (`items_category`),
  CONSTRAINT `cardex_ibfk_1` FOREIGN KEY (`brand_category`) REFERENCES `brand` (`id`),
  CONSTRAINT `cardex_ibfk_2` FOREIGN KEY (`items_category`) REFERENCES `items` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;

INSERT INTO `cardex` VALUES ('29','oui','Mr','Patfoort','Romuald','romuald.patfoort@gmail.com','603124194','1','6','password','','2021-01-12');


DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `items` VALUES ('3','écran');
INSERT INTO `items` VALUES ('5','imprimante');
INSERT INTO `items` VALUES ('1','pc portable');
INSERT INTO `items` VALUES ('4','tablette');
INSERT INTO `items` VALUES ('2','tour');
